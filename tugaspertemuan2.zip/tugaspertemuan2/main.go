package main

import "fmt"

/* buatkan function untuk studi kasus berikut :
- diketahui ada product sepatu  adidas , puma, kappa
- harga sepatu adidas 200.000
- harga sepatu puma 150.000
- harga sepatu kappa 600.000
 
- harga diskon
- jika membeli sepatu adidas dan puma potongan 50.000
- jika membeli sepatu puma dan kappa potongan 150.000
- jika membeli sepatu adidas dan kappa potongan 75.000

- tentukan total yang harus dibayarkan 
 

*/

const (
	hargaAdidas = 200000
	hargaPuma   = 150000
	hargaKappa  = 600000
)

func totalBayar(beliAdidas, beliPuma, beliKappa bool) int {
	total := 0
	diskon := 0

	if beliAdidas {
		total += hargaAdidas
	}
	if beliPuma {
		total += hargaPuma
	}
	if beliKappa {
		total += hargaKappa
	}

	if beliAdidas && beliPuma {
		diskon += 50000
	}
	if beliPuma && beliKappa {
		diskon += 150000
	}
	if beliAdidas && beliKappa {
		diskon += 75000
	}

	total -= diskon

	return total
}

func main() {
	beliAdidas := true
	beliPuma := true
	beliKappa := false

	total := totalBayar(beliAdidas, beliPuma, beliKappa)
	fmt.Printf("Total yang harus dibayarkan: Rp %d\n", total)
}
